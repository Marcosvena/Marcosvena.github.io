package cofre;

//CLASSE FILHA DE MOEDA 

public class Real extends Moeda {

	public Real(double valorinicial) {
		this.valor = valorinicial;
	}
	@Override
	public void info() {
		System.out.println("Real " + valor);
	
	}
	@Override
	public double converter() {
		return this.valor; 
		
	}
	
	@Override
	public boolean equals(Object objeto) {
		if (this.getClass() != getClass()) {
			return false;
		}
		
		Real objetoDeReal = (Real) objeto;
		
		if(this.valor != objetoDeReal.valor) {
			return false;
		}
		return true;
	}
}
