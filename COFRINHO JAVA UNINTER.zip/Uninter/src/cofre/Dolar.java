package cofre;

//CLASSE FILHA DE MOEDA

public class Dolar extends Moeda {
	
	public Dolar(double valor1) {
		this.valor = valor1;
	}
	
	public void info() {
		System.out.println("Dolar " + valor);
		
	}
	
	//CONVERTER VALOR DE DOLAR EM REAL
	@Override
	public double converter() {
		return this.valor * 4.90;
	}
	

	@Override
	public boolean equals(Object objeto) {
		if (this.getClass() != objeto.getClass()) {
			return false;
		}
		
		Dolar objetoDeDolar = (Dolar) objeto;
		
		if(this.valor != objetoDeDolar.valor) {
			return false;
		}
		return true;
	}

}
