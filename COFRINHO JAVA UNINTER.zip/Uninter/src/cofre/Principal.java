package cofre;

//CLASSE PRINCIPAL DO CÓDIGO, ONDE TUDO SE INICIA 
public class Principal {

	public static void main(String[] args) {
		
		Menu menu = new Menu();
		menu.MenuPrincipal();
	
	}

}
