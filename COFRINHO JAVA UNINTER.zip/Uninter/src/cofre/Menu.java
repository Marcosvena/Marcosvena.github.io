package cofre;

import java.util.Scanner;

public class Menu {
	
	private Scanner sc;
	private Cofrinho cofrinho;
	
	public Menu() {
		sc = new Scanner(System.in);
		cofrinho = new Cofrinho();
	}
	
	//AQUI TEMOS O MENU CONTENDO AS OPÇÕES DE ESCOLHAS DO USUÁRIO
	
	public void MenuPrincipal() {
		System.out.println("BEM VINDO AO COFRINHO JAVA");
		System.out.println("1-Adicionar moeda:");
		System.out.println("2-Remover moeda:");
		System.out.println("3-Listar moedas");
		System.out.println("4-Valor convertido para real:");
		System.out.println("0-Encerrar");
		
		String opcaoSelecionada = sc.next();
		
		switch (opcaoSelecionada) {
		
		// AS OPÇÕES SEMPRE ACABAM RETORNANDO O MENU PRINCIPAL,
		
		case "0":
			System.out.println("Até breve!");
			break;
			
		case "1":
			menuSecundarioAdicionarMoeda();
			MenuPrincipal();
			break;
			
		case "2":
			menuSecundariRemoverMoeda();
			MenuPrincipal();
			break;
			
		case "3":
			cofrinho.listagemMoedas();
			MenuPrincipal();
			break;
			
		case "4":
			double valorTotalConvertido = cofrinho.totalConvertido();
			String valorTotalConvertidoTexto = String.valueOf(valorTotalConvertido);
			valorTotalConvertidoTexto = valorTotalConvertidoTexto.replace("." , ",");
			System.out.println("O valor convertido para Real: " + valorTotalConvertido);
			MenuPrincipal();
			break;
			
		default:
			System.out.println("Escolha inválida!");
			MenuPrincipal();
			break;
		}
		
	}
	
	//O MENU SECUNDARIO É PARA DETALHAR COM MAIS PRECISÃO,
	//FUNCIONANDO COMO UM SUBMENU DENTRO DO MENU PRINCIPAL  
	
	private void menuSecundarioAdicionarMoeda() {
		System.out.println("Escolha uma moeda:");
		System.out.println("1 - Real:");
		System.out.println("2 - Euro:");
		System.out.println("3 - Dolar:");
		
		int opcaoMoeda = sc.nextInt();
		
		System.out.println("Digite o valor:");
		String valorTextoMoeda = sc.next();
		valorTextoMoeda = valorTextoMoeda.replace("," , ".");
		double valorMoeda = Double.parseDouble(valorTextoMoeda);

		Moeda moeda = null;
		
		if (opcaoMoeda == 1) {
			 moeda = new Real(valorMoeda);
			cofrinho.adicionar(moeda);
		} else if (opcaoMoeda == 2) {
			 moeda = new Euro (valorMoeda);
			cofrinho.adicionar(moeda);
		} else if (opcaoMoeda == 3) {
			 moeda = new Dolar (valorMoeda);
			cofrinho.adicionar(moeda);
		} else {
			System.out.println("Escolha Invalida");
			MenuPrincipal();
		}
		
	}
	
	//AO REMOVER UMA MOEDA, SÓ SERÁ MOSTRADO O RESULTADO AO LISTAR ESCOLHENDO A OPÇÃO 3
	
	private void menuSecundariRemoverMoeda() {
		System.out.println("Escolha uma moeda:");
		System.out.println("1 - Real:");
		System.out.println("2 - Euro:");
		System.out.println("3 - Dolar:");
		
		int opcaoMoeda = sc.nextInt();
		
		System.out.println("Digite o valor:");
		String valorTextoMoeda = sc.next();
		valorTextoMoeda = valorTextoMoeda.replace("," , ".");
		double valorMoeda = Double.parseDouble(valorTextoMoeda);

		Moeda moeda = null;
		
		if (opcaoMoeda == 1) {
			 moeda = new Real(valorMoeda);
			cofrinho.remover(moeda);
		} else if (opcaoMoeda == 2) {
			 moeda = new Euro (valorMoeda);
			cofrinho.remover(moeda);
		} else if (opcaoMoeda == 3) {
			 moeda = new Dolar (valorMoeda);
			cofrinho.remover(moeda);
		} else {
			System.out.println("Escolha Invalida");
			MenuPrincipal();
		}
		
		cofrinho.remover (moeda);
	}
}
